@echo off
cd /d "%~dp0"
start "" "WrongTurnCounts.exe"
